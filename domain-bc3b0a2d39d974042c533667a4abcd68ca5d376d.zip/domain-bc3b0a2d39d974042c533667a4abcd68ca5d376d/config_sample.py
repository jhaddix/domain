reconPath = "/usr/share/recon-ng/"
altDnsPath = "/root/Desktop/altdns-master/"
